﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraphQL.API.GraphqlCore
{
    public class TechEventSchema : Schema
    {
        public TechEventSchema(IDependencyResolver resolver) : base(resolver)
        {
            Query = resolver.Resolve<TechEventQuery>();
            DependencyResolver = resolver;
        }

    }
}
